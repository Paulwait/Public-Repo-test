# This is to ensure we call setup_extended_logging() before anything else.
import eth as _eth_module  # noqa: F401
