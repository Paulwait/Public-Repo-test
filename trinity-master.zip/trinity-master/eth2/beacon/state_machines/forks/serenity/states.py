from eth2.beacon.types.states import BeaconState


class SerenityBeaconState(BeaconState):
    pass
