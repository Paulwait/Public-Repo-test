# External Plugins

This directory is for plugins that do not come bundled with Trinity itself and hence need to be installed through pip.

## Installing plugins from PyPi

Run: `pip install <plugin-pypi-name>

## Installing plugins from local directory

Run `pip install /path/to/plugin`