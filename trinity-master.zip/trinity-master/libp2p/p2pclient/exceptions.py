class ControlFailure(Exception):
    pass


class DispatchFailure(Exception):
    pass
