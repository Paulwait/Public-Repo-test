control_maddr_str = "/unix/tmp/p2pd.sock"
listen_maddr_str = "/unix/tmp/p2pclient.sock"
