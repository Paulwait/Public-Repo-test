Release notes
=============

Trinity and Py-EVM are moving fast. Learn about the latest improvements in the release notes.

.. toctree::
   :maxdepth: 2
   :name: toc-release-notes

   trinity.rst
