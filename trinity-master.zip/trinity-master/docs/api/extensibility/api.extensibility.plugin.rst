Plugin
======


PluginContext
-------------

.. autoclass:: trinity.extensibility.plugin.PluginContext
  :members:

BasePlugin
----------

.. autoclass:: trinity.extensibility.plugin.BasePlugin
  :members:

BaseAsyncStopPlugin
-------------------

.. autoclass:: trinity.extensibility.plugin.BaseAsyncStopPlugin
  :members:

BaseMainProcessPlugin
---------------------

.. autoclass:: trinity.extensibility.plugin.BaseMainProcessPlugin
  :members:

BaseIsolatedPlugin
------------------

.. autoclass:: trinity.extensibility.plugin.BaseIsolatedPlugin
  :members: