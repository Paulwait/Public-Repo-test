Exceptions
==========

.. autoclass:: trinity.extensibility.exceptions.EventBusNotReady
  :members:

.. autoclass:: trinity.extensibility.exceptions.UnsuitableShutdownError
  :members:

