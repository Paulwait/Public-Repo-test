PluginManager
=============

BaseManagerProcessScope
-----------------------

.. autoclass:: trinity.extensibility.plugin_manager.BaseManagerProcessScope
  :members:

MainAndIsolatedProcessScope
---------------------------

.. autoclass:: trinity.extensibility.plugin_manager.MainAndIsolatedProcessScope
  :members:

SharedProcessScope
------------------

.. autoclass:: trinity.extensibility.plugin_manager.SharedProcessScope
  :members:

PluginManager
-------------

.. autoclass:: trinity.extensibility.plugin_manager.PluginManager
  :members:

