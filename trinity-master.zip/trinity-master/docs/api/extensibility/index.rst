Extensibility
=============

.. warning::

  The extensibility API isn't stable yet. Expect breaking changes.

.. toctree::
   :maxdepth: 4
   :name: toc-eth-api-extensibility

   api.extensibility.events.rst
   api.extensibility.exceptions.rst
   api.extensibility.plugin.rst
   api.extensibility.plugin_manager.rst

