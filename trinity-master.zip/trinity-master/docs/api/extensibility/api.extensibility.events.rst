Events
======

.. autoclass:: trinity.extensibility.events.PluginStartedEvent
  :members:

.. autoclass:: trinity.extensibility.events.ResourceAvailableEvent
  :members:
