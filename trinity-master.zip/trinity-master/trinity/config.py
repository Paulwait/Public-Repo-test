from abc import (
    ABC,
    abstractmethod,
)
import argparse
from contextlib import contextmanager
from enum import (
    auto,
    Enum,
)
import json
from pathlib import Path
from typing import (
    Any,
    cast,
    Dict,
    Iterable,
    TYPE_CHECKING,
    Tuple,
    Type,
    TypeVar,
    Union,
)

from eth_typing import (
    Address,
)

from eth_keys import keys
from eth_keys.datatypes import PrivateKey

from eth.db.backends.base import BaseAtomicDB
from eth.typing import VMConfiguration

from py_ecc import bls

from p2p.kademlia import Node as KademliaNode
from p2p.constants import (
    MAINNET_BOOTNODES,
    ROPSTEN_BOOTNODES,
)

from trinity.constants import (
    ASSETS_DIR,
    DEFAULT_PREFERRED_NODES,
    IPC_DIR,
    LOG_DIR,
    LOG_FILE,
    MAINNET_NETWORK_ID,
    PID_DIR,
    ROPSTEN_NETWORK_ID,
    SYNC_LIGHT,
)
from trinity._utils.chains import (
    construct_trinity_config_params,
    get_data_dir_for_network_id,
    get_database_socket_path,
    get_jsonrpc_socket_path,
    get_nodekey_path,
    load_nodekey,
)
from trinity._utils.eip1085 import (
    Account,
    GenesisData,
    GenesisParams,
    extract_genesis_data,
)
from trinity._utils.filesystem import (
    PidFile,
)
from trinity._utils.xdg import (
    get_xdg_trinity_root,
)

from eth2.beacon.constants import (
    ZERO_TIMESTAMP,
)
from eth2.beacon.state_machines.forks.serenity import (
    SERENITY_CONFIG,
    SerenityStateMachine,
)
from eth2.beacon.tools.builder.initializer import (
    create_mock_genesis,
)
from eth2.beacon.state_machines.forks.serenity.blocks import (
    SerenityBeaconBlock,
)


if TYPE_CHECKING:
    # avoid circular import
    from trinity.nodes.base import Node  # noqa: F401
    from trinity.chains.full import FullChain  # noqa: F401
    from trinity.chains.light import LightDispatchChain  # noqa: F401
    from eth2.beacon.chains.base import BeaconChain  # noqa: F401

DATABASE_DIR_NAME = 'chain'

MAINNET_EIP1085_PATH = ASSETS_DIR / 'eip1085' / 'mainnet.json'
ROPSTEN_EIP1085_PATH = ASSETS_DIR / 'eip1085' / 'ropsten.json'


PRECONFIGURED_NETWORKS = {MAINNET_NETWORK_ID, ROPSTEN_NETWORK_ID}


def _load_preconfigured_genesis_config(network_id: int) -> Dict[str, Any]:
    if network_id == MAINNET_NETWORK_ID:
        with MAINNET_EIP1085_PATH.open('r') as mainnet_genesis_file:
            return json.load(mainnet_genesis_file)
    elif network_id == ROPSTEN_NETWORK_ID:
        with ROPSTEN_EIP1085_PATH.open('r') as ropsten_genesis_file:
            return json.load(ropsten_genesis_file)
    else:
        raise TypeError(f"Unknown or unsupported `network_id`: {network_id}")


def _get_preconfigured_chain_name(network_id: int) -> str:
    if network_id == MAINNET_NETWORK_ID:
        return 'MainnetChain'
    elif network_id == ROPSTEN_NETWORK_ID:
        return 'RopstenChain'
    else:
        raise TypeError(f"Unknown or unsupported `network_id`: {network_id}")


class ChainConfig:
    def __init__(self,
                 genesis_data: GenesisData,
                 chain_name: str=None) -> None:

        self.genesis_data = genesis_data
        self._chain_name = chain_name

    @property
    def chain_name(self) -> str:
        if self._chain_name is None:
            return "CustomChain"
        else:
            return self._chain_name

    @property
    def full_chain_class(self) -> Type['FullChain']:
        from trinity.chains.full import FullChain  # noqa: F811

        return FullChain.configure(
            __name__=self.chain_name,
            vm_configuration=self.vm_configuration,
            chain_id=self.chain_id,
        )

    @property
    def light_chain_class(self) -> Type['LightDispatchChain']:
        from trinity.chains.light import LightDispatchChain  # noqa: F811

        return LightDispatchChain.configure(
            __name__=self.chain_name,
            vm_configuration=self.vm_configuration,
            chain_id=self.chain_id,
        )

    @classmethod
    def from_eip1085_genesis_config(cls,
                                    genesis_config: Dict[str, Any],
                                    chain_name: str=None,
                                    ) -> 'ChainConfig':
        genesis_data = extract_genesis_data(genesis_config)
        return cls(
            genesis_data=genesis_data,
            chain_name=chain_name,
        )

    @classmethod
    def from_preconfigured_network(cls,
                                   network_id: int) -> 'ChainConfig':
        genesis_config = _load_preconfigured_genesis_config(network_id)
        chain_name = _get_preconfigured_chain_name(network_id)
        return cls.from_eip1085_genesis_config(genesis_config, chain_name)

    @property
    def chain_id(self) -> int:
        return self.genesis_data.chain_id

    @property
    def genesis_params(self) -> GenesisParams:
        """
        Return the genesis configuation parsed from the genesis configuration file.
        """
        return self.genesis_data.params

    @property
    def genesis_state(self) -> Dict[Address, Account]:
        return self.genesis_data.state

    def initialize_chain(self,
                         base_db: BaseAtomicDB) -> 'FullChain':
        genesis_params = self.genesis_params.to_dict()
        genesis_state = {
            address: account.to_dict()
            for address, account
            in self.genesis_state.items()
        }
        return cast('FullChain', self.full_chain_class.from_genesis(
            base_db=base_db,
            genesis_params=genesis_params,
            genesis_state=genesis_state,
        ))

    @property
    def vm_configuration(self) -> VMConfiguration:
        """
        Return the vm configuration specifed from the genesis configuration file.
        """
        return self.genesis_data.vm_configuration


TAppConfig = TypeVar('TAppConfig', bound='BaseAppConfig')


class TrinityConfig:
    _trinity_root_dir: Path = None

    _chain_config: ChainConfig = None

    _data_dir: Path = None
    _nodekey_path: Path = None
    _logfile_path: Path = None
    _nodekey = None
    _network_id: int = None

    port: int = None
    preferred_nodes: Tuple[KademliaNode, ...] = None

    bootstrap_nodes: Tuple[KademliaNode, ...] = None

    _genesis_config: Dict[str, Any] = None

    _app_configs: Dict[Type['BaseAppConfig'], 'BaseAppConfig'] = None

    def __init__(self,
                 network_id: int,
                 app_identifier: str="",
                 genesis_config: Dict[str, Any]=None,
                 max_peers: int=25,
                 trinity_root_dir: str=None,
                 data_dir: str=None,
                 nodekey_path: str=None,
                 nodekey: PrivateKey=None,
                 port: int=30303,
                 use_discv5: bool = False,
                 preferred_nodes: Tuple[KademliaNode, ...]=None,
                 bootstrap_nodes: Tuple[KademliaNode, ...]=None) -> None:
        self.app_identifier = app_identifier
        self.network_id = network_id
        self.max_peers = max_peers
        self.port = port
        self.use_discv5 = use_discv5
        self._app_configs = {}

        if genesis_config is not None:
            self.genesis_config = genesis_config
        elif network_id in PRECONFIGURED_NETWORKS:
            self.genesis_config = _load_preconfigured_genesis_config(network_id)
        else:
            raise TypeError(
                "No `genesis_config` was provided and the `network_id` is not "
                "in the known preconfigured networks.  Cannot initialize "
                "ChainConfig"
            )

        if trinity_root_dir is not None:
            self.trinity_root_dir = trinity_root_dir

        if not preferred_nodes and self.network_id in DEFAULT_PREFERRED_NODES:
            self.preferred_nodes = DEFAULT_PREFERRED_NODES[self.network_id]
        else:
            self.preferred_nodes = preferred_nodes

        if bootstrap_nodes is None:
            if self.network_id == MAINNET_NETWORK_ID:
                self.bootstrap_nodes = tuple(
                    KademliaNode.from_uri(enode) for enode in MAINNET_BOOTNODES
                )
            elif self.network_id == ROPSTEN_NETWORK_ID:
                self.bootstrap_nodes = tuple(
                    KademliaNode.from_uri(enode) for enode in ROPSTEN_BOOTNODES
                )
            else:
                self.bootstrap_nodes = tuple()
        else:
            self.bootstrap_nodes = bootstrap_nodes

        if data_dir is not None:
            self.data_dir = data_dir

        if nodekey is not None and nodekey_path is not None:
            raise ValueError("It is invalid to provide both a `nodekey` and a `nodekey_path`")
        elif nodekey_path is not None:
            self.nodekey_path = nodekey_path
        elif nodekey is not None:
            self.nodekey = nodekey

    def get_chain_config(self) -> ChainConfig:
        # the `ChainConfig` object cannot be pickled so we can't cache this
        # value since the TrinityConfig is sent across process boundaries.
        if self.network_id in PRECONFIGURED_NETWORKS:
            return ChainConfig.from_preconfigured_network(self.network_id)
        else:
            return ChainConfig.from_eip1085_genesis_config(self.genesis_config)

    @property
    def app_suffix(self) -> str:
        return "" if len(self.app_identifier) == 0 else f"-{self.app_identifier}"

    @property
    def logfile_path(self) -> Path:
        """
        Return the path to the log file.
        """
        return self.log_dir / LOG_FILE

    @property
    def log_dir(self) -> Path:
        """
        Return the path of the directory where all log files are stored.
        """
        return self.with_app_suffix(self.data_dir / LOG_DIR)

    @property
    def trinity_root_dir(self) -> Path:
        """
        The trinity_root_dir is the base directory that all trinity data is
        stored under.

        The default ``data_dir`` path will be resolved relative to this
        directory.
        """
        if self._trinity_root_dir is not None:
            return self._trinity_root_dir
        else:
            return get_xdg_trinity_root()

    @trinity_root_dir.setter
    def trinity_root_dir(self, value: str) -> None:
        self._trinity_root_dir = Path(value).resolve()

    @property
    def trinity_root_dir(self) -> Path:
        """
        The trinity_root_dir is the base directory that all trinity data is
        stored under.

        The default ``data_dir`` path will be resolved relative to this
        directory.
        """
        if self._trinity_root_dir is not None:
            return self._trinity_root_dir
        else:
            return get_xdg_trinity_root()

    @trinity_root_dir.setter
    def trinity_root_dir(self, value: str) -> None:
        self._trinity_root_dir = Path(value).resolve()

    @property
    def data_dir(self) -> Path:
        """
        The data_dir is the base directory that all chain specific information
        for a given chain is stored.

        All defaults for chain directories are resolved relative to this
        directory.
        """
        if self._data_dir is not None:
            return self._data_dir
        else:
            return get_data_dir_for_network_id(self.network_id, self.trinity_root_dir)

    @data_dir.setter
    def data_dir(self, value: str) -> None:
        self._data_dir = Path(value).resolve()

    @property
    def database_ipc_path(self) -> Path:
        """
        Path for the database IPC socket connection.
        """
        return get_database_socket_path(self.ipc_dir)

    @property
    def ipc_dir(self) -> Path:
        """
        The base directory for all open IPC files.
        """
        return self.with_app_suffix(self.data_dir / IPC_DIR)

    @property
    def pid_dir(self) -> Path:
        """
        The base directory for all PID files.
        """
        return self.with_app_suffix(self.data_dir / PID_DIR)

    @property
    def jsonrpc_ipc_path(self) -> Path:
        """
        Path for the JSON-RPC server IPC socket.
        """
        return get_jsonrpc_socket_path(self.ipc_dir)

    @property
    def nodekey_path(self) -> Path:
        """
        Path where the nodekey is stored
        """
        if self._nodekey_path is None:
            if self._nodekey is not None:
                return None
            else:
                return get_nodekey_path(self.data_dir)
        else:
            return self._nodekey_path

    @nodekey_path.setter
    def nodekey_path(self, value: str) -> None:
        self._nodekey_path = Path(value).resolve()

    @property
    def nodekey(self) -> PrivateKey:
        if self._nodekey is None:
            try:
                return load_nodekey(self.nodekey_path)
            except FileNotFoundError:
                # no file at the nodekey_path so we have a null nodekey
                return None
        else:
            if isinstance(self._nodekey, bytes):
                return keys.PrivateKey(self._nodekey)
            elif isinstance(self._nodekey, PrivateKey):
                return self._nodekey
            return self._nodekey

    @nodekey.setter
    def nodekey(self, value: Union[bytes, PrivateKey]) -> None:
        if isinstance(value, bytes):
            self._nodekey = keys.PrivateKey(value)
        elif isinstance(value, PrivateKey):
            self._nodekey = value
        else:
            raise TypeError(
                "Nodekey must either be a raw byte-string or an eth_keys "
                f"`PrivateKey` instance: got {type(self._nodekey)}"
            )

    @contextmanager
    def process_id_file(self, process_name: str):  # type: ignore
        with PidFile(process_name, self.pid_dir):
            yield

    @classmethod
    def from_parser_args(cls,
                         parser_args: argparse.Namespace,
                         app_identifier: str,
                         app_config_types: Iterable[Type['BaseAppConfig']]) -> 'TrinityConfig':
        """
        Helper function for initializing from the namespace object produced by
        an ``argparse.ArgumentParser``
        """
        constructor_kwargs = construct_trinity_config_params(parser_args)
        trinity_config = cls(app_identifier=app_identifier, **constructor_kwargs)

        trinity_config.initialize_app_configs(parser_args, app_config_types)

        return trinity_config

    def initialize_app_configs(self,
                               parser_args: argparse.Namespace,
                               app_config_types: Iterable[Type['BaseAppConfig']]) -> None:
        """
        Initialize all available ``BaseAppConfig`` based on their concrete types,
        the ``parser_args`` and the existing ``TrinityConfig`` instance.
        """
        for app_config_type in app_config_types:
            self.add_app_config(app_config_type.from_parser_args(parser_args, self))

    def add_app_config(self, app_config: 'BaseAppConfig') -> None:
        """
        Register the given ``app_config``.
        """
        self._app_configs[type(app_config)] = app_config

    def has_app_config(self, app_config_type: Type['BaseAppConfig']) -> bool:
        """
        Check if a ``BaseAppConfig`` exists based on the given ``app_config_type``.
        """
        return app_config_type in self._app_configs.keys()

    def get_app_config(self, app_config_type: Type[TAppConfig]) -> TAppConfig:
        """
        Return the ``BaseAppConfig`` derived instance based on the given ``app_config_type``.
        """
        # We want this API to return the specific type of the app config that is requested.
        # Our backing field only knows that it is holding `BaseAppConfig`'s but not concrete types
        return cast(TAppConfig, self._app_configs[app_config_type])

    def with_app_suffix(self, path: Path) -> Path:
        return path.with_name(path.name + self.app_suffix)


class BaseAppConfig(ABC):

    def __init__(self, trinity_config: TrinityConfig):
        self.trinity_config = trinity_config

    @classmethod
    @abstractmethod
    def from_parser_args(cls,
                         args: argparse.Namespace,
                         trinity_config: TrinityConfig) -> 'BaseAppConfig':
        """
        Initialize from the namespace object produced by
        an ``argparse.ArgumentParser`` and the ``TrinityConfig``
        """
        pass


class Eth1DbMode(Enum):

    FULL = auto()
    LIGHT = auto()


class Eth1AppConfig(BaseAppConfig):

    def __init__(self, trinity_config: TrinityConfig, sync_mode: str):
        super().__init__(trinity_config)
        self.trinity_config = trinity_config
        self._sync_mode = sync_mode

    @classmethod
    def from_parser_args(cls,
                         args: argparse.Namespace,
                         trinity_config: TrinityConfig) -> 'BaseAppConfig':
        return cls(trinity_config, args.sync_mode)

    @property
    def database_dir(self) -> Path:
        """
        Path where the chain database will be stored.

        This is resolved relative to the ``data_dir``
        """
        path = self.trinity_config.data_dir / DATABASE_DIR_NAME
        if self.database_mode is Eth1DbMode.LIGHT:
            return self.trinity_config.with_app_suffix(path) / "light"
        elif self.database_mode is Eth1DbMode.FULL:
            return self.trinity_config.with_app_suffix(path) / "full"
        else:
            raise Exception(f"Unsupported Database Mode: {self.database_mode}")

    @property
    def database_mode(self) -> Eth1DbMode:
        if self.sync_mode == SYNC_LIGHT:
            return Eth1DbMode.LIGHT
        else:
            return Eth1DbMode.FULL

    @property
    def node_class(self) -> Type['Node']:
        """
        The ``Node`` class that trinity will use.
        """
        from trinity.nodes.full import FullNode
        from trinity.nodes.light import LightNode

        if self.database_mode is Eth1DbMode.FULL:
            return FullNode
        elif self.database_mode is Eth1DbMode.LIGHT:
            return LightNode
        else:
            raise NotImplementedError(f"Database mode {self.database_mode} not supported")

    @property
    def sync_mode(self) -> str:
        return self._sync_mode

    @property
    def nodedb_path(self) -> Path:
        config = self.trinity_config
        return config.with_app_suffix(config.data_dir / "nodedb")


class BeaconChainConfig:
    def __init__(self,
                 chain_name: str=None) -> None:
        self._chain_name = chain_name
        self.chain_id = 5566
        self.network_id = 5567

        self.sm_configuration = (
            (SERENITY_CONFIG.GENESIS_SLOT, SerenityStateMachine),
        )

    @property
    def chain_name(self) -> str:
        if self._chain_name is None:
            return "CustomBeaconChain"
        else:
            return self._chain_name

    @property
    def beacon_chain_class(self) -> Type['BeaconChain']:
        from eth2.beacon.chains.base import BeaconChain  # noqa: F811
        return BeaconChain.configure(
            __name__=self.chain_name,
            sm_configuration=self.sm_configuration,
            chain_id=self.chain_id,
        )

    def initialize_chain(self,
                         base_db: BaseAtomicDB) -> 'BeaconChain':
        config = SERENITY_CONFIG

        # Only used for testing
        num_validators = 10
        privkeys = tuple(2 ** i for i in range(num_validators))
        keymap = {}
        for k in privkeys:
            keymap[bls.privtopub(k)] = k
        state, block = create_mock_genesis(
            num_validators=num_validators,
            config=config,
            keymap=keymap,
            genesis_block_class=SerenityBeaconBlock,
            genesis_time=ZERO_TIMESTAMP,
        )
        return cast('BeaconChain', self.beacon_chain_class.from_genesis(
            base_db=base_db,
            genesis_state=state,
            genesis_block=block,
        ))


class BeaconAppConfig(BaseAppConfig):

    @classmethod
    def from_parser_args(cls,
                         args: argparse.Namespace,
                         trinity_config: TrinityConfig) -> 'BaseAppConfig':
        if args is not None:
            # This is quick and dirty way to get bootstrap_nodes
            trinity_config.bootstrap_nodes = tuple(
                KademliaNode.from_uri(enode) for enode in args.bootstrap_nodes.split(',')
            ) if args.bootstrap_nodes is not None else tuple()
            trinity_config.preferred_nodes = tuple(
                KademliaNode.from_uri(enode) for enode in args.preferred_nodes.split(',')
            ) if args.preferred_nodes is not None else tuple()
        return cls(trinity_config)

    @property
    def database_dir(self) -> Path:
        """
        Path where the chain database will be stored.

        This is resolved relative to the ``data_dir``
        """
        path = self.trinity_config.data_dir / DATABASE_DIR_NAME
        return self.trinity_config.with_app_suffix(path) / "full"

    def get_chain_config(self) -> BeaconChainConfig:
        return BeaconChainConfig("TestnetChain")
