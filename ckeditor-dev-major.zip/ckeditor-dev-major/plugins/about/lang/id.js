/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'id', {
	copy: 'Hak cipta &copy; $1. All rights reserved.',
	dlgTitle: 'Tentang CKEditor 4',
	moreInfo: 'Untuk informasi lisensi silahkan kunjungi web site kami:'
} );
