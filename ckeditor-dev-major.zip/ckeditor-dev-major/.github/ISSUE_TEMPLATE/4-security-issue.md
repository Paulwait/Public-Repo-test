---
name: "\U0001F6A8 Security issue"
about: Report a security issue.
title: ''
labels: ''
assignees: ''

---

⚠️ Please **DO NOT report security issues here**, use the contact form at https://ckeditor.com/contact/ instead. ⚠️
